import React, { useEffect, useRef, useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface VideoBackgroundProps {
  className?: string;
}

export function VideoBackground({ className = "" }: VideoBackgroundProps) {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Mock video URLs - in a real app, these would be actual 360 booth videos
  const videoSources = [
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
  ];

  // Fallback images for when videos don't load
  const fallbackImages = [
    "https://images.unsplash.com/photo-1632266092205-f001e66bb19a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzNjAlMjBwaG90byUyMGJvb3RoJTIwd2VkZGluZ3xlbnwxfHx8fDE3NTYwNzcxNTF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    "https://images.unsplash.com/photo-1742991106935-eaec5df86ae1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjBldmVudCUyMHBob3RvJTIwYm9vdGh8ZW58MXx8fHwxNzU2MDc3MTU2fDA&ixlib=rb-4.1.0&q=80&w=1080",
    "https://images.unsplash.com/photo-1542622498-64942a97e930?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxldmVudCUyMGNlbGVicmF0aW9uJTIwcGFydHl8ZW58MXx8fHwxNzU2MDc3MTYxfDA&ixlib=rb-4.1.0&q=80&w=1080"
  ];

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleVideoEnd = () => {
      setCurrentVideoIndex((prevIndex) => 
        (prevIndex + 1) % videoSources.length
      );
    };

    const handleLoadedData = () => {
      setIsVideoLoaded(true);
    };

    const handleError = () => {
      setIsVideoLoaded(false);
    };

    video.addEventListener('ended', handleVideoEnd);
    video.addEventListener('loadeddata', handleLoadedData);
    video.addEventListener('error', handleError);
    
    return () => {
      video.removeEventListener('ended', handleVideoEnd);
      video.removeEventListener('loadeddata', handleLoadedData);
      video.removeEventListener('error', handleError);
    };
  }, [videoSources.length]);

  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.load();
      video.play().catch(() => {
        setIsVideoLoaded(false);
      });
    }
  }, [currentVideoIndex]);

  // Auto-rotate images when video isn't loaded
  useEffect(() => {
    if (!isVideoLoaded) {
      const interval = setInterval(() => {
        setCurrentVideoIndex((prevIndex) => 
          (prevIndex + 1) % fallbackImages.length
        );
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isVideoLoaded, fallbackImages.length]);

  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Video Element */}
      <video
        ref={videoRef}
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
          isVideoLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        muted
        playsInline
        preload="auto"
      >
        <source src={videoSources[currentVideoIndex]} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      {/* Fallback Image */}
      <ImageWithFallback
        src={fallbackImages[currentVideoIndex]}
        alt="360 Photo Booth Experience"
        className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${
          !isVideoLoaded ? 'opacity-100' : 'opacity-0'
        }`}
      />
      
      {/* Overlay for better text readability */}
      <div className="absolute inset-0 bg-black/40" />
      
      {/* Futuristic overlay pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent animate-pulse" />
        <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute left-0 top-0 w-1 h-full bg-gradient-to-b from-transparent via-primary to-transparent animate-pulse" style={{ animationDelay: '0.5s' }} />
        <div className="absolute right-0 top-0 w-1 h-full bg-gradient-to-b from-transparent via-accent to-transparent animate-pulse" style={{ animationDelay: '1.5s' }} />
      </div>
      
      {/* Content indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2 z-10">
        {(isVideoLoaded ? videoSources : fallbackImages).map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentVideoIndex(index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentVideoIndex 
                ? 'bg-primary glow-primary' 
                : 'bg-white/30 hover:bg-white/50'
            }`}
          />
        ))}
      </div>

      {/* 360 Booth Label */}
      <div className="absolute bottom-8 right-8 backdrop-glow rounded-lg px-4 py-2 z-10">
        <span className="text-primary text-sm">🎪 360° Booth Experience</span>
      </div>
    </div>
  );
}