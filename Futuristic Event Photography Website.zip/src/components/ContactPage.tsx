import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    eventType: '',
    eventDate: '',
    venue: '',
    guestCount: '',
    serviceType: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Booking submitted:', formData);
    alert('Thank you for your booking request! We\'ll contact you within 24 hours to confirm details.');
  };

  const packageOptions = [
    {
      name: "Essential",
      price: "$599",
      duration: "3 hours",
      features: ["360° or Selfie booth", "Basic props", "Digital delivery", "Setup & breakdown"]
    },
    {
      name: "Premium", 
      price: "$899",
      duration: "4 hours",
      features: ["360° + Selfie booth", "Premium props", "Custom branding", "On-site attendant", "Instant sharing"]
    },
    {
      name: "Luxury",
      price: "$1299",
      duration: "6 hours",
      features: ["All booth types", "Unlimited props", "Custom backdrop", "Professional lighting", "Same-day highlights reel"]
    }
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-transparent to-accent" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 container mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-6xl mb-4 text-glow-primary">
            Book Your Event
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Transform your celebration into an unforgettable experience. Let's create magic together.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Booking Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-2 backdrop-glow rounded-lg p-8"
          >
            <h2 className="text-2xl mb-6 text-glow-primary">Event Details</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Contact Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm mb-2 text-primary">Full Name *</label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="bg-input-background border-glow"
                    placeholder="Enter your full name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm mb-2 text-primary">Email Address *</label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="bg-input-background border-glow"
                    placeholder="your@email.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="phone" className="block text-sm mb-2 text-primary">Phone Number *</label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="bg-input-background border-glow"
                    placeholder="(555) 123-4567"
                  />
                </div>
                <div>
                  <label htmlFor="eventDate" className="block text-sm mb-2 text-primary">Event Date *</label>
                  <Input
                    id="eventDate"
                    name="eventDate"
                    type="date"
                    value={formData.eventDate}
                    onChange={handleInputChange}
                    required
                    className="bg-input-background border-glow"
                  />
                </div>
              </div>

              {/* Event Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="eventType" className="block text-sm mb-2 text-primary">Event Type *</label>
                  <select
                    id="eventType"
                    name="eventType"
                    value={formData.eventType}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 bg-input-background border border-primary/20 rounded-md 
                             focus:outline-none focus:border-primary transition-colors"
                  >
                    <option value="">Select event type</option>
                    <option value="wedding">Wedding</option>
                    <option value="corporate">Corporate Event</option>
                    <option value="birthday">Birthday Party</option>
                    <option value="anniversary">Anniversary</option>
                    <option value="graduation">Graduation</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="guestCount" className="block text-sm mb-2 text-primary">Expected Guests</label>
                  <Input
                    id="guestCount"
                    name="guestCount"
                    value={formData.guestCount}
                    onChange={handleInputChange}
                    className="bg-input-background border-glow"
                    placeholder="Approximate number"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="venue" className="block text-sm mb-2 text-primary">Venue/Location</label>
                  <Input
                    id="venue"
                    name="venue"
                    value={formData.venue}
                    onChange={handleInputChange}
                    className="bg-input-background border-glow"
                    placeholder="Event venue or address"
                  />
                </div>
                <div>
                  <label htmlFor="serviceType" className="block text-sm mb-2 text-primary">Preferred Service *</label>
                  <select
                    id="serviceType"
                    name="serviceType"
                    value={formData.serviceType}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 bg-input-background border border-primary/20 rounded-md 
                             focus:outline-none focus:border-primary transition-colors"
                  >
                    <option value="">Select service</option>
                    <option value="360-booth">360° Photo Booth</option>
                    <option value="selfie-booth">Selfie Booth</option>
                    <option value="both">Both Services</option>
                    <option value="custom">Custom Package</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm mb-2 text-primary">Special Requests & Additional Details</label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={4}
                  className="bg-input-background border-glow resize-none"
                  placeholder="Tell us about your vision, theme, or any special requirements..."
                />
              </div>

              <Button 
                type="submit"
                className="w-full bg-primary/20 hover:bg-primary/40 border-glow text-primary 
                         hover:text-white transition-all duration-300 glow-primary py-6 text-lg"
              >
                Submit Booking Request
              </Button>
            </form>
          </motion.div>

          {/* Packages & Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-6"
          >
            {/* Quick Info */}
            <div className="backdrop-glow rounded-lg p-6">
              <h3 className="text-xl mb-4 text-glow-primary">Quick Response Promise</h3>
              <div className="space-y-3 text-sm text-muted-foreground">
                <div className="flex items-center gap-3">
                  <span className="text-primary">⚡</span>
                  <span>24-hour response guarantee</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-primary">💬</span>
                  <span>Free consultation call</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-primary">📋</span>
                  <span>Customized quote</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-primary">✅</span>
                  <span>No hidden fees</span>
                </div>
              </div>
            </div>

            {/* Packages */}
            <div className="space-y-4">
              <h3 className="text-xl text-glow-primary">Popular Packages</h3>
              {packageOptions.map((pkg, index) => (
                <motion.div
                  key={pkg.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                  className="backdrop-glow rounded-lg p-4 hover:border-glow transition-all duration-300 group"
                >
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-primary">{pkg.name}</h4>
                    <div className="text-right">
                      <div className="text-lg text-glow-primary">{pkg.price}</div>
                      <div className="text-xs text-muted-foreground">{pkg.duration}</div>
                    </div>
                  </div>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <span className="w-1 h-1 bg-primary rounded-full"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
              
              <div className="text-center text-sm text-muted-foreground mt-4">
                * Prices vary by location and date. Custom packages available.
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}