import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface NavigationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: 'home' | 'gallery' | 'contact') => void;
}

export function NavigationDropdown({ isOpen, onClose, onNavigate }: NavigationDropdownProps) {
  const menuItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'gallery', label: 'Gallery', icon: '📸' },
    { id: 'contact', label: 'Book Event', icon: '📅' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40"
            onClick={onClose}
          />
          
          {/* Dropdown Menu */}
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="absolute top-20 right-4 z-50 backdrop-glow rounded-lg p-2 min-w-[160px]"
          >
            {menuItems.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1, duration: 0.2 }}
                onClick={() => {
                  onNavigate(item.id as 'home' | 'gallery' | 'contact');
                  onClose();
                }}
                className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-md
                         hover:bg-primary/10 hover:border-glow transition-all duration-200
                         text-foreground hover:text-primary group"
              >
                <span className="text-xl group-hover:animate-float">{item.icon}</span>
                <span className="group-hover:text-glow-primary">{item.label}</span>
              </motion.button>
            ))}
            
            {/* Decorative border effect */}
            <div className="absolute inset-0 rounded-lg border border-primary/20 pointer-events-none" />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}