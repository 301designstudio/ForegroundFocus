import React from 'react';
import { motion } from 'motion/react';

export function ServicesSection() {
  const services = [
    {
      title: "360° Photo Booth",
      description: "Immersive 360-degree video experiences that capture every angle",
      features: ["Slow-motion capture", "Instant sharing", "Custom branding", "LED lighting"],
      icon: "🎪"
    },
    {
      title: "Selfie Booth",
      description: "Interactive photo experiences with endless customization",
      features: ["Green screen options", "Digital props", "Social media integration", "Instant prints"],
      icon: "📸"
    },
    {
      title: "Event Packages",
      description: "Complete event solutions tailored to your needs",
      features: ["Setup & breakdown", "On-site attendant", "Custom backdrop", "Digital gallery"],
      icon: "✨"
    }
  ];

  return (
    <section className="py-20 px-6 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-transparent to-accent" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 container mx-auto max-w-6xl">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-6 text-glow-primary">
            Our Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From intimate weddings to large corporate events, we provide cutting-edge photo booth experiences 
            that create lasting memories and drive engagement.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="backdrop-glow rounded-lg p-6 hover:border-glow transition-all duration-300 group h-full"
            >
              {/* Service Icon */}
              <div className="text-4xl mb-4 group-hover:animate-float">
                {service.icon}
              </div>

              {/* Service Title */}
              <h3 className="text-xl mb-3 text-glow-primary group-hover:text-glow-secondary transition-all duration-300">
                {service.title}
              </h3>

              {/* Service Description */}
              <p className="text-muted-foreground mb-4 leading-relaxed">
                {service.description}
              </p>

              {/* Features List */}
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="w-2 h-2 bg-primary rounded-full glow-primary flex-shrink-0"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* Hover Glow Effect */}
              <div className="absolute inset-0 border border-primary/0 group-hover:border-primary/30 
                            rounded-lg transition-all duration-300 pointer-events-none opacity-0 
                            group-hover:opacity-100 glow-primary" />
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-16"
        >
          <div className="backdrop-glow rounded-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl mb-4 text-glow-primary">Ready to Elevate Your Event?</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              Let us transform your celebration into an unforgettable experience with our state-of-the-art 
              booth technology and professional service.
            </p>
            <button className="px-8 py-3 bg-primary/20 hover:bg-primary/40 border-glow rounded-lg
                             transition-all duration-300 text-primary hover:text-white glow-primary
                             hover:scale-105 transform">
              Book Your Event Today
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}