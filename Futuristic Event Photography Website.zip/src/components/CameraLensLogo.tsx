import React from 'react';

interface CameraLensLogoProps {
  size?: number;
  className?: string;
  onClick?: () => void;
}

export function CameraLensLogo({ size = 60, className = "", onClick }: CameraLensLogoProps) {
  return (
    <div 
      className={`relative cursor-pointer group ${className}`}
      onClick={onClick}
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        className="relative z-10 transition-all duration-300 group-hover:scale-110"
      >
        {/* Outer ring */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="none"
          stroke="url(#outerGradient)"
          strokeWidth="2"
          className="glow-primary"
        />
        
        {/* Middle ring */}
        <circle
          cx="50"
          cy="50"
          r="35"
          fill="none"
          stroke="url(#middleGradient)"
          strokeWidth="1.5"
        />
        
        {/* Inner ring */}
        <circle
          cx="50"
          cy="50"
          r="25"
          fill="none"
          stroke="url(#innerGradient)"
          strokeWidth="1"
        />
        
        {/* Aperture blades */}
        <g className="animate-spin" style={{ transformOrigin: '50px 50px', animationDuration: '20s' }}>
          {[0, 45, 90, 135, 180, 225, 270, 315].map((angle, index) => (
            <path
              key={index}
              d="M50,25 L55,35 L45,35 Z"
              fill="url(#bladeGradient)"
              transform={`rotate(${angle} 50 50)`}
              className="opacity-70"
            />
          ))}
        </g>
        
        {/* Center dot */}
        <circle
          cx="50"
          cy="50"
          r="3"
          fill="url(#centerGradient)"
          className="animate-pulse-glow"
        />
        
        {/* Gradients */}
        <defs>
          <linearGradient id="outerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" />
            <stop offset="50%" stopColor="#0099cc" />
            <stop offset="100%" stopColor="#00d4ff" />
          </linearGradient>
          
          <linearGradient id="middleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#0099cc" stopOpacity="0.8" />
          </linearGradient>
          
          <linearGradient id="innerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#0099cc" stopOpacity="0.6" />
          </linearGradient>
          
          <linearGradient id="bladeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#0066aa" stopOpacity="0.9" />
          </linearGradient>
          
          <radialGradient id="centerGradient">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#00d4ff" />
          </radialGradient>
        </defs>
      </svg>
      
      {/* Glow effect background */}
      <div 
        className="absolute inset-0 rounded-full glow-primary opacity-30 group-hover:opacity-50 transition-opacity duration-300"
        style={{ transform: 'scale(1.2)' }}
      />
    </div>
  );
}