import React from 'react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function GalleryPage() {
  // Mock gallery data
  const galleryItems = [
    {
      id: 1,
      title: "Wedding Celebration - Sarah & Mike",
      type: "360° Booth",
      image: "wedding celebration 360",
      description: "Beautiful 360° moments captured at the Grand Ballroom"
    },
    {
      id: 2,
      title: "Corporate Event - Tech Summit 2024",
      type: "Selfie Booth",
      image: "corporate event selfie booth",
      description: "Professional networking with interactive photo experiences"
    },
    {
      id: 3,
      title: "Anniversary Party - Golden Years",
      type: "360° Booth",
      image: "anniversary party 360",
      description: "50 years of love celebrated in style"
    },
    {
      id: 4,
      title: "Product Launch - Innovation Expo",
      type: "Selfie Booth",
      image: "product launch event",
      description: "Cutting-edge technology meets memorable moments"
    },
    {
      id: 5,
      title: "Charity Gala - Hearts Together",
      type: "360° Booth",
      image: "charity gala 360",
      description: "Glamorous evening for a great cause"
    },
    {
      id: 6,
      title: "Company Holiday Party",
      type: "Selfie Booth",
      image: "holiday party corporate",
      description: "Team building through shared memories"
    }
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-br from-primary via-transparent to-accent" />
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-primary rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-6 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-6xl mb-4 text-glow-primary">
            Event Gallery
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover the magic we've captured at weddings, corporate events, and special celebrations
          </p>
        </motion.div>

        {/* Gallery Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {galleryItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative backdrop-glow rounded-lg overflow-hidden cursor-pointer
                         hover:scale-105 transition-all duration-300"
            >
              {/* Image */}
              <div className="aspect-video relative overflow-hidden">
                <ImageWithFallback
                  src={`https://images.unsplash.com/800x600/?${encodeURIComponent(item.image)}`}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              {/* Content Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="text-sm text-primary mb-1 glow-primary">{item.type}</div>
                <h3 className="text-lg mb-2 text-glow-primary">{item.title}</h3>
                <p className="text-sm text-muted-foreground opacity-0 group-hover:opacity-100 
                             transition-opacity duration-300">
                  {item.description}
                </p>
              </div>

              {/* Hover Glow Effect */}
              <div className="absolute inset-0 border border-primary/0 group-hover:border-primary/50 
                            rounded-lg transition-all duration-300 pointer-events-none glow-primary opacity-0 
                            group-hover:opacity-100" />
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-16"
        >
          <div className="backdrop-glow rounded-lg p-8 max-w-2xl mx-auto">
            <h2 className="text-2xl mb-4 text-glow-primary">Ready to Create Your Own Memories?</h2>
            <p className="text-muted-foreground mb-6">
              Let us bring the magic to your next event with our state-of-the-art 360° and selfie booths
            </p>
            <button className="px-8 py-3 bg-primary/20 hover:bg-primary/30 border-glow rounded-lg
                             transition-all duration-300 text-primary hover:text-white glow-primary">
              Get Started Today
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}