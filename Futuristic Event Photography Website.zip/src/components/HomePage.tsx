import React from 'react';
import { motion } from 'motion/react';
import { VideoBackground } from './VideoBackground';
import { ServicesSection } from './ServicesSection';

export function HomePage() {
  return (
    <div className="relative">
      {/* Hero Section with Video Background */}
      <div className="relative h-screen overflow-hidden">
        {/* Video Background */}
        <VideoBackground className="absolute inset-0" />
        
        {/* Hero Content */}
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-center px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="max-w-4xl mx-auto"
          >
            {/* Main Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="text-5xl md:text-7xl lg:text-8xl mb-6 text-glow-primary animate-float"
            >
              FUTURE
              <br />
              <span className="text-glow-secondary">BOOTH</span>
            </motion.h1>
            
            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="text-xl md:text-2xl lg:text-3xl mb-12 text-muted-foreground max-w-3xl mx-auto leading-relaxed"
            >
              Immersive 360° & Selfie Experiences for
              <br />
              <span className="text-primary text-glow-primary">Weddings</span> & <span className="text-accent text-glow-accent">Corporate Events</span>
            </motion.p>
            
            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-6 justify-center"
            >
              <button className="px-10 py-4 bg-primary/20 hover:bg-primary/40 border-glow rounded-lg
                               transition-all duration-300 text-primary hover:text-white glow-primary
                               text-lg hover:scale-105 transform">
                Book Your Event
              </button>
              <button className="px-10 py-4 bg-transparent hover:bg-accent/20 border-glow rounded-lg
                               transition-all duration-300 text-accent hover:text-white
                               text-lg hover:scale-105 transform">
                View Gallery
              </button>
            </motion.div>
          </motion.div>
          
          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          >
            <div className="flex flex-col items-center gap-2">
              <span className="text-xs text-muted-foreground uppercase tracking-widest">
                Discover Our Services
              </span>
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-6 h-10 border border-primary/50 rounded-full flex justify-center p-1 cursor-pointer"
                onClick={() => {
                  document.getElementById('services-section')?.scrollIntoView({ 
                    behavior: 'smooth' 
                  });
                }}
              >
                <div className="w-1 h-3 bg-primary rounded-full glow-primary" />
              </motion.div>
            </div>
          </motion.div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute inset-0 pointer-events-none z-10">
          {/* Corner accents */}
          <div className="absolute top-0 left-0 w-32 h-32 border-l-2 border-t-2 border-primary/30" />
          <div className="absolute top-0 right-0 w-32 h-32 border-r-2 border-t-2 border-primary/30" />
          <div className="absolute bottom-0 left-0 w-32 h-32 border-l-2 border-b-2 border-accent/30" />
          <div className="absolute bottom-0 right-0 w-32 h-32 border-r-2 border-b-2 border-accent/30" />
          
          {/* Floating particles */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-primary rounded-full glow-primary"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [-20, 20, -20],
                opacity: [0.3, 1, 0.3],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      </div>
      
      {/* Services Section */}
      <div id="services-section" className="bg-background">
        <ServicesSection />
      </div>
    </div>
  );
}