# Deployment Guide: From Code to Live Website

This guide will walk you through uploading your 360° booth website to GitHub and deploying it as a live website.

## Step 1: Set Up Git and GitHub Repository

### 1.1 Install Git (if not already installed)
- Download from [git-scm.com](https://git-scm.com/)
- Verify installation: `git --version`

### 1.2 Create GitHub Account
- Sign up at [github.com](https://github.com) if you don't have an account

### 1.3 Create New Repository
1. Go to GitHub and click "New repository"
2. Name it: `360-booth-website` (or your preferred name)
3. Set to Public (for free GitHub Pages hosting)
4. Don't initialize with README (we already have one)
5. Click "Create repository"

## Step 2: Upload Your Code to GitHub

### 2.1 Initialize Git in Your Project
Open terminal/command prompt in your project folder and run:

```bash
# Initialize git repository
git init

# Add all files to git
git add .

# Create first commit
git commit -m "Initial commit: 360° booth website"

# Connect to your GitHub repository (replace with your username/repo)
git remote add origin https://github.com/YOURUSERNAME/360-booth-website.git

# Push code to GitHub
git push -u origin main
```

### 2.2 Verify Upload
- Go to your GitHub repository URL
- You should see all your files uploaded

## Step 3: Deploy to Live Website

You have several hosting options. Here are the three most popular:

### Option A: Deploy with Vercel (Recommended for React)

**Why Vercel?**
- Free tier available
- Automatic deployments from GitHub
- Excellent performance for React apps
- Custom domain support

**Steps:**
1. Go to [vercel.com](https://vercel.com)
2. Sign up with your GitHub account
3. Click "New Project"
4. Import your `360-booth-website` repository
5. Vercel auto-detects it's a React app
6. Click "Deploy"
7. Your site will be live at: `https://your-repo-name.vercel.app`

**Custom Domain (Optional):**
- In Vercel dashboard, go to your project
- Click "Domains" tab
- Add your custom domain (e.g., `360booth.com`)
- Follow DNS configuration instructions

### Option B: Deploy with Netlify

**Why Netlify?**
- Free tier with generous limits
- Easy drag-and-drop deployment
- Form handling built-in
- Good for static sites

**Steps:**
1. Build your project locally:
   ```bash
   npm install
   npm run build
   ```
2. Go to [netlify.com](https://netlify.com)
3. Sign up and click "Add new site"
4. Choose "Deploy manually" and drag your `dist` folder
5. Or connect GitHub for automatic deployments

### Option C: GitHub Pages (Free but Limited)

**Why GitHub Pages?**
- Completely free
- Integrated with GitHub
- Good for simple static sites

**Steps:**
1. In your GitHub repository, go to Settings
2. Scroll to "Pages" section
3. Source: Deploy from a branch
4. Branch: `main` or create `gh-pages` branch
5. Folder: `/ (root)` or `/docs`
6. Save settings
7. Your site will be at: `https://yourusername.github.io/360-booth-website`

**Note:** For GitHub Pages with React, you might need to:
- Add `"homepage": "https://yourusername.github.io/360-booth-website"` to package.json
- Install gh-pages: `npm install --save-dev gh-pages`
- Add deploy script: `"deploy": "gh-pages -d dist"`

## Step 4: Set Up Continuous Deployment

### For Vercel/Netlify with GitHub:
- Any push to your main branch automatically deploys
- Pull requests create preview deployments
- Easy rollbacks through dashboard

### Workflow:
1. Make changes to your code
2. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Update: description of changes"
   git push
   ```
3. Site automatically rebuilds and deploys

## Step 5: Custom Domain Setup (Optional)

### 5.1 Purchase Domain
- Use providers like Namecheap, GoDaddy, or Cloudflare

### 5.2 Configure DNS
For Vercel:
- Add CNAME record pointing to `cname.vercel-dns.com`
- Or A record pointing to Vercel's IP

For Netlify:
- Add CNAME record pointing to your Netlify domain
- Or use Netlify's DNS service

### 5.3 Add Domain to Hosting Platform
- Go to your hosting dashboard
- Add custom domain
- Follow SSL certificate setup

## Step 6: Environment Variables (If Needed)

If you add features requiring API keys:

### Vercel:
- Go to Project Settings → Environment Variables
- Add variables like `VITE_API_KEY`

### Netlify:
- Go to Site Settings → Environment Variables
- Add your variables

### In Code:
```typescript
const apiKey = import.meta.env.VITE_API_KEY;
```

## Step 7: Performance Optimization

### 7.1 Build Optimization
Your Vite setup already includes:
- Code splitting
- Asset optimization
- Tree shaking

### 7.2 SEO Setup
Update `index.html` with:
- Proper meta descriptions
- Open Graph tags
- Schema markup

### 7.3 Analytics (Optional)
Add Google Analytics or other tracking:
```html
<!-- In index.html head -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
```

## Troubleshooting

### Common Issues:

**Build Fails:**
- Check all imports are correct
- Ensure all dependencies are in package.json
- Verify TypeScript errors

**Site Not Loading:**
- Check build output for errors
- Verify all assets are properly referenced
- Check browser console for errors

**Routing Issues:**
- For single-page apps, configure redirects
- Vercel: Create `vercel.json` with rewrites
- Netlify: Create `_redirects` file

### Support Resources:
- [Vercel Documentation](https://vercel.com/docs)
- [Netlify Documentation](https://docs.netlify.com)
- [GitHub Pages Documentation](https://pages.github.com)

## Next Steps

Once deployed, consider:
1. Setting up monitoring (Sentry, LogRocket)
2. Adding contact form backend
3. Implementing booking system
4. Adding CMS for content management
5. Setting up email notifications

Your 360° booth website is now live and accessible to the world! 🚀