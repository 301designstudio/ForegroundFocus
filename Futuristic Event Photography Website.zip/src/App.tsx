import React, { useState } from "react";
import { CameraLensLogo } from "./components/CameraLensLogo";
import { NavigationDropdown } from "./components/NavigationDropdown";
import { HomePage } from "./components/HomePage";
import { GalleryPage } from "./components/GalleryPage";
import { ContactPage } from "./components/ContactPage";

type PageType = "home" | "gallery" | "contact";

export default function App() {
  const [currentPage, setCurrentPage] =
    useState<PageType>("home");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavigate = (page: PageType) => {
    setCurrentPage(page);
    setIsMenuOpen(false);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "gallery":
        return <GalleryPage />;
      case "contact":
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      {/* Navigation Header */}
      <header className="fixed top-0 right-0 z-50 p-4">
        <CameraLensLogo
          size={60}
          onClick={toggleMenu}
          className="animate-float"
        />
        <NavigationDropdown
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          onNavigate={handleNavigate}
        />
      </header>

      {/* Main Content */}
      <main className="relative">{renderCurrentPage()}</main>
    </div>
  );
}